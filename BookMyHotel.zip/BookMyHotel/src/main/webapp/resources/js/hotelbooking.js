

function getHotels(){
var city=$("#sel_city").val();
var lessprice=false;
if($('#hotel_table').length >0) {  
	lessprice=true;
}
$.ajax({ 
    type: 'GET', 
    url: 'http://localhost:8080/city/'+city+'/hotel?lessprice='+lessprice, 
    dataType: 'json',
    success: function (data) { 
    	if($('#hotel_table').length >0) {    	
    	$("#hotel_table tbody tr").remove();
        $.each(data, function(index, h) {
        	 var htmlrow ="<tr><td>"+ h.hotelName+"</td><td>"+h.address+"</td><td>"+h.mobileNumber+"</td><td>"+h.price+"</td><td>"+h.roomCount+"</td></tr>";         
            $('#hotel_table').append(htmlrow);
        });        
    	}else{
    		$("#sel_hotel option").remove();
    		$('#sel_hotel').append('<option value="0">--Choose your Hotel--</option>');
    		$.each(data, function(index, h) {
               $('#sel_hotel').append('<option price='+h.price+' rooms='+h.roomCount+' value='+h.id+'>'+h.hotelName+'</option>');
           });        
    	}
    }
});
}

function getHotelDetails(){
	var price=$('#sel_hotel option:selected').attr('price');
	var rooms=$('#sel_hotel option:selected').attr('rooms');
	$("#totalRooms").text("Max rooms:"+rooms);
	$("#roomPrice").text("Price/Room:"+price);
}

/*$(document).ready(function(){
$("#roombooked").keyup(function() {
	var price=parseInt($('#sel_hotel option:selected').attr('price'));
	var roomsBooked=parseInt($("#roombooked").val());
	var days=$("#days").text();
	var total=parseFloat(roomsBooked * price * days * 1.0 );
	if(isNaN(total)){
		total=0;
	}
	total=total.toFixed(2);
$("#amount").val(total);	
});
});	*/


$( function() {
var dateFormat = "dd/mm/yy",
from = $( "#from" )
.datepicker({
defaultDate: "+1w",
changeMonth: true,
numberOfMonths: 1,
minDate:new Date(),
dateFormat:dateFormat
})
.on( "change", function() {
to.datepicker( "option", "minDate", getDate( this ,"from") );
calculateDays();
}),
to = $( "#to" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
numberOfMonths: 1,
dateFormat:dateFormat
})
.on( "change", function() {
from.datepicker( "option", "maxDate", getDate( this ,"to") );
calculateDays();
});



function getDate( element ,type) {
var date;
try {
date = $.datepicker.parseDate( dateFormat, element.value );
if(type!="from"){
date.setDate(date.getDate()-1);
}else{
	date.setDate(date.getDate()+1);
}
} catch( error ) {
date = null;
}
return date;
}
function calculateDays() {
    var d1 = $('#from').datepicker('getDate');
    var d2 = $('#to').datepicker('getDate');
    var diff = 1;
    if (d1 && d2) {
        diff = diff + Math.floor((d2.getTime() - d1.getTime()) / 86400000); 
    }
    $('#days').text(" No of Days:"+diff)
}
} );
//////////////////////////////////
$(document).ready(function() {
    $("#roombooked").keydown(function (e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 return;
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
});
package com.bookmyhotel.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.bookmyhotel.model.Booking;
import com.bookmyhotel.model.Hotel;
import com.bookmyhotel.model.User;
import com.bookmyhotel.service.BookingService;
import com.bookmyhotel.service.HotelService;

@Component
public class BookingValidator implements Validator {
 
	@Autowired
	private BookingService bookingService;
	
	@Autowired
	private HotelService hotelService;
	
    @Override
    public boolean supports(Class<?> aClass) {
        return User.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        Booking booking = (Booking) o;
        Hotel hotel=null;
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fromDate", "NotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "toDate", "NotEmpty");
        if(booking.getFromDate()!=null && booking.getToDate() !=null){
        	if(booking.getFromDate().after(booking.getToDate())){
        		errors.rejectValue("fromDate", "Booking.invalid.date.range");
        	}
        }
        if(booking.getHotel()==null || booking.getHotel().getId()==0){
        	 errors.rejectValue("hotel.id", "NotEmpty");
        }else{
        	 hotel=hotelService.findById(booking.getHotel().getId());
        	 bookingService.setTotalAmount(booking, hotel.getPrice());
        	  int totalRooms=hotel.getRoomCount();
        	  if (booking.getRooms()==null || booking.getRooms()<1 ) {
                  errors.rejectValue("rooms", "Booking.invalid.rooms");
              }else if (booking.getRooms()>totalRooms ) {
                  errors.rejectValue("rooms", "Booking.invalid.rooms.exceeded");
              }else if(bookingService.getRoomsAvailable(booking,totalRooms)<booking.getRooms()){
              	 errors.rejectValue("rooms", "Booking.invalid.rooms.unavailable");
              }
        }
       
       
        if (booking.getAmount()<1 ) {
            errors.rejectValue("amount", "Booking.invalid.amount");
        }
        
        
      
        
    }
}
package com.bookmyhotel.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.bookmyhotel.service.BookingServiceImpl;
//..
//@ControllerAdvice
public class ExceptionControllerAdvice {
    private static final Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);

	/*@ExceptionHandler(Exception.class)
	public ModelAndView exception(Exception e) {
		logger.error("Exception Handled:"+e.getMessage());
		ModelAndView mav = new ModelAndView("error");
		mav.addObject("name", e.getClass().getSimpleName());
		mav.addObject("message", e.getMessage());
		return mav;
	}*/
}

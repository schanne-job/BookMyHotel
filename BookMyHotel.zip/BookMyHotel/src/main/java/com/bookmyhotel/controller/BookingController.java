package com.bookmyhotel.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bookmyhotel.exception.HotelBookingBussinessException;
import com.bookmyhotel.model.Booking;
import com.bookmyhotel.model.City;
import com.bookmyhotel.model.User;
import com.bookmyhotel.service.BookingService;
import com.bookmyhotel.service.CityService;
import com.bookmyhotel.service.UserService;
import com.bookmyhotel.util.Constants;
import com.bookmyhotel.validator.BookingValidator;

@Controller
public class BookingController {
	
	@Autowired
    private UserService userService;
	
	@Autowired
	private BookingService bookingService;

	@Autowired
	private BookingValidator bookingValidator;
	
	@Autowired
    private CityService cityService;
	
	
   
    
      
    @RequestMapping(value = {"/booking/{bookingId}"}, method = RequestMethod.GET)
    public String getBookingDetail(Model model,@PathVariable long bookingId) { 
    	try{
    		Booking booking=bookingService.findById(bookingId);
        	model.addAttribute(Constants.BOOKING, booking);
    	}catch (HotelBookingBussinessException e) {
        	model.addAttribute(Constants.ERROR,"Invalid Booking Id");
		}  	
    	
    	return "viewbooking";
    }
    
    @RequestMapping(value = {"/home","/MyBookings"}, method = RequestMethod.GET)
    public String myBookings(Model model) { 
    	String userName=SecurityContextHolder.getContext().getAuthentication().getName();
    	User user=userService.findByUsername(userName);
    	try{
    	List<Booking> bookings=bookingService.findByUser(user);
    	model.addAttribute("bookings", bookings);
    	}catch (HotelBookingBussinessException e) {
    		model.addAttribute("noBookings","You have no previous bookings");
		}
    	return "home";
    }
    
    @RequestMapping(value = {"/error"}, method = RequestMethod.GET)
    public String erroe(Model model) { 
    	
    	return "error";
    }
    
    @RequestMapping(value = {"/booking"}, method = RequestMethod.GET)
    public String bookingForm(Model model, HttpServletRequest req) { 
    	List<City> cities=cityService.findAll();
    	model.addAttribute(Constants.CITIES, cities);
    	model.addAttribute(Constants.BOOKING, new Booking());
    	return "hotel_booking";
    }
    @RequestMapping(value = {"/booking"}, method = RequestMethod.POST)
    public String bookingSubmit(@ModelAttribute Booking booking,BindingResult bindingResult,RedirectAttributes redirAttrib ,Model model, HttpServletRequest req) {  
    	bookingValidator.validate(booking, bindingResult);
    	if(bindingResult.hasErrors()){
    		model.addAttribute(Constants.CITIES, cityService.findAll());    		
    		return "hotel_booking";
    	}
    	booking.setBookingDate(new Date());
    	String username=SecurityContextHolder.getContext().getAuthentication().getName();
    	User user=userService.findByUsername(username);
    	booking.setUser(user);
    	booking=bookingService.save(booking);    	
    	redirAttrib.addFlashAttribute(Constants.MESSAGE, "Booking.request.success");
    	redirAttrib.addFlashAttribute("bId", booking.getId());
    	return "redirect:/booking";
    }
    
    
    
    
    
}

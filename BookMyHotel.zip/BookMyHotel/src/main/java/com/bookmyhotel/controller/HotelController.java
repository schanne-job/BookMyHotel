package com.bookmyhotel.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bookmyhotel.model.City;
import com.bookmyhotel.model.Hotel;
import com.bookmyhotel.service.CityService;
import com.bookmyhotel.service.HotelService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class HotelController {
		
	@Autowired
    private CityService cityService;
	
	@Autowired
    private HotelService hotelService;
   
      
    @RequestMapping(value = {"/","/hotels"}, method = RequestMethod.GET)
    public String welcome(Model model, HttpServletRequest req) {    	
    	List<City> cities=cityService.findAll();
    	model.addAttribute("cities", cities);
    	return "hotels";
    }
    
    @RequestMapping(value = { "/city/{cityId}/hotel"}, method = RequestMethod.GET)
    @ ResponseBody public String getHotelsInCity(@RequestParam(required = false) boolean lessprice, Model model,@PathVariable long cityId) {
    	City city=new City();
    	city.setId(cityId);
    	List<Hotel> hotels=hotelService.findByCity(city,lessprice);
    	String result="error";
    	ObjectMapper om= new ObjectMapper();
    	try {
			 result=om.writeValueAsString(hotels);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
    	return result;    	
    }
    
    
    
}

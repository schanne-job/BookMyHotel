package com.bookmyhotel.service;

import java.util.List;

import com.bookmyhotel.exception.HotelBookingBussinessException;
import com.bookmyhotel.model.City;
import com.bookmyhotel.model.Hotel;

public interface HotelService {
	void save(Hotel hotel) ;
	Hotel findById(Long id) throws HotelBookingBussinessException;
	List<Hotel> findByCity(City city,boolean lessPrice) throws HotelBookingBussinessException;
}

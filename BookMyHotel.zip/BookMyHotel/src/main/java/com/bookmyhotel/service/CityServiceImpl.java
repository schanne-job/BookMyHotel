package com.bookmyhotel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookmyhotel.model.City;
import com.bookmyhotel.repository.CityRepository;

@Service
public class CityServiceImpl implements CityService {
    @Autowired
    private CityRepository cityRepository;

	@Override
	public void save(City city) {
		cityRepository.save(city);		
	}

	@Override
	public City findById(Long id) {
		return cityRepository.getOne(id);
	}

	@Override
	public List<City> findAll() {
		return cityRepository.findAll();
	}
    
	
}
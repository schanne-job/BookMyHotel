package com.bookmyhotel.service;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.stereotype.Service;

import com.bookmyhotel.exception.HotelBookingBussinessException;
import com.bookmyhotel.model.Booking;
import com.bookmyhotel.model.Hotel;
import com.bookmyhotel.model.User;
import com.bookmyhotel.repository.BookingRepository;

@Service
public class BookingServiceImpl implements BookingService {
    @Autowired
    private BookingRepository bookingRepository;

    private static final Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);

    
	@Override
	public Booking save(Booking booking) {
		return bookingRepository.save(booking);	
	}

	@Override
	public Booking findById(Long id) {
		try{
		return bookingRepository.getOne(id);
		}catch (EntityNotFoundException e) {
			logger.info("No Booking Entity Found Exception:"+e.toString());
			throw new HotelBookingBussinessException(e.getMessage());
		}catch(InvalidDataAccessApiUsageException e){
			logger.info("DataAccessException:"+e.toString());
			throw new HotelBookingBussinessException(e.getMessage());
		}		
	}

	@Override
	public List<Booking> findByUser(User user){
		try{
		return bookingRepository.findByUserOrderByBookingDateDesc(user);
		}catch(InvalidDataAccessApiUsageException e){
				logger.info("DataAccessException:"+e.toString());
				throw new HotelBookingBussinessException(e.getMessage());
			}
	}

	@Override
	public List<Booking> findByHotel(Hotel hotel) {
		try{
		return bookingRepository.findByHotel(hotel);
		}catch (EntityNotFoundException e) {
			logger.info("No Booking found by hotel:"+e.toString());
			throw new HotelBookingBussinessException(e.getMessage());		
			}catch(InvalidDataAccessApiUsageException e){
				logger.info("DataAccessException:"+e.toString());
				throw new HotelBookingBussinessException(e.getMessage());
			}
	}

	@Override
	public void setTotalAmount(Booking booking, double price) {
		if(booking.getFromDate()==null || booking.getToDate()==null || booking.getRooms()==null)
			return;
		Calendar calFrom = Calendar.getInstance();
		Calendar calTo = Calendar.getInstance();
		calFrom.setTime(booking.getFromDate());
		calTo.setTime(booking.getToDate());		
		long milliSecDiff=calTo.getTimeInMillis()-calFrom.getTimeInMillis();
		int days=(int)milliSecDiff/ (24 * 60 * 60 * 1000);
		double amount=booking.getRooms()*price*days;
		booking.setAmount(amount);
		
	}

	@Override
	public int getRoomsAvailable(Booking booking,int totalRooms) {
		List<Booking> bookigs=bookingRepository.findByFromDateAndToDate(booking.getFromDate(),booking.getToDate(),booking.getHotel().getId());
		int roomsOccupied=0;
		for(Booking b :bookigs){
			roomsOccupied+=b.getRooms();
		}		
		return totalRooms-roomsOccupied;
		
	}
	
	@Override
	public String getBookingNo(Booking booking) {
		
		return booking.getId()+"-"+booking.getBookingDate().getMonth();
		
	}
	
}
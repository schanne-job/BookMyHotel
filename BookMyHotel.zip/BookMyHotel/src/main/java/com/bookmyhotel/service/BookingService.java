package com.bookmyhotel.service;

import java.util.List;

import com.bookmyhotel.exception.HotelBookingBussinessException;
import com.bookmyhotel.model.Booking;
import com.bookmyhotel.model.Hotel;
import com.bookmyhotel.model.User;

public interface BookingService {
	Booking save(Booking booking) throws HotelBookingBussinessException;
	Booking findById(Long id)  throws HotelBookingBussinessException;
	List<Booking> findByUser(User user)  throws HotelBookingBussinessException;
	List<Booking> findByHotel(Hotel hotel)  throws HotelBookingBussinessException;
	void setTotalAmount(Booking booking, double d) ;
	int getRoomsAvailable(Booking booking, int totalRooms);
	String getBookingNo(Booking booking);
	
}

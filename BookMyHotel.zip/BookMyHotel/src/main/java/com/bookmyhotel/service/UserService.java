package com.bookmyhotel.service;

import com.bookmyhotel.model.User;

public interface UserService {
	void save(User user);

    User findByUsername(String username);
}

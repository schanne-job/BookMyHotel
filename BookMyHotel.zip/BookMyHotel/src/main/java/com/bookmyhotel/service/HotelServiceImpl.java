package com.bookmyhotel.service;

import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.stereotype.Service;

import com.bookmyhotel.exception.HotelBookingBussinessException;
import com.bookmyhotel.model.City;
import com.bookmyhotel.model.Hotel;
import com.bookmyhotel.repository.HotelRepository;

@Service
public class HotelServiceImpl implements HotelService {
    @Autowired
    private HotelRepository hotelRepository;

    private static final Logger logger = LoggerFactory.getLogger(HotelServiceImpl.class);

	@Override
	public void save(Hotel hotel) {
		hotelRepository.save(hotel);		
	}

	@Override
	public Hotel findById(Long id) {
		try{
		return hotelRepository.getOne(id);
		}catch (EntityNotFoundException e) {
			logger.info("No hotel found:"+e.toString());
			throw new HotelBookingBussinessException(e.getMessage());		
			}catch(InvalidDataAccessApiUsageException e){
				logger.info("DataAccessException:"+e.toString());
				throw new HotelBookingBussinessException(e.getMessage());
			}
	}

	@Override
	public List<Hotel> findByCity(City city,boolean lessPrice) {
		try{
			if(lessPrice){		
			return hotelRepository.findTop5ByCityOrderByPriceAsc(city);
		}
		return hotelRepository.findByCityOrderByPriceAsc(city);
		}
		catch (EntityNotFoundException e) {
			logger.info("No Hotel found by city:"+e.toString());
			throw new HotelBookingBussinessException(e.getMessage());		
			}catch(InvalidDataAccessApiUsageException e){
				logger.info("DataAccessException:"+e.toString());
				throw new HotelBookingBussinessException(e.getMessage());
			}
	}
   
}
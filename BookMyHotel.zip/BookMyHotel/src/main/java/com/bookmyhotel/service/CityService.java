package com.bookmyhotel.service;

import java.util.List;

import com.bookmyhotel.model.City;

public interface CityService {
	void save(City city);

	City findById(Long id);
	List<City> findAll();
}

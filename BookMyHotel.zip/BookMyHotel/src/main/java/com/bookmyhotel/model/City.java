package com.bookmyhotel.model;


import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;

@Entity
@Table(name = "city")
public class City {
    private Long id;
    private String name;
    private  Set<Hotel> hotelList;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "city",fetch=FetchType.LAZY)
	public Set<Hotel> getHotelList() {
		return hotelList;
	}

	public void setHotelList(Set<Hotel> hotelList) {
		this.hotelList = hotelList;
	}


    
}
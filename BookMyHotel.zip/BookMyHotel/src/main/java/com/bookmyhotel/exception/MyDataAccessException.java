package com.bookmyhotel.exception;

public class MyDataAccessException extends RuntimeException{

	private static final long serialVersionUID = 2954991403330435608L;
	
	private String errMsg;


	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public MyDataAccessException( String errMsg) {
		super();
		this.errMsg = errMsg;
	}
	
	
}

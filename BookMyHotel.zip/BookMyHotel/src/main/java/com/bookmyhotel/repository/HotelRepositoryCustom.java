package com.bookmyhotel.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bookmyhotel.model.City;
import com.bookmyhotel.model.Hotel;
@Repository
public interface HotelRepositoryCustom {
    List<Hotel> findByCityWithLessPrice(City city);
}
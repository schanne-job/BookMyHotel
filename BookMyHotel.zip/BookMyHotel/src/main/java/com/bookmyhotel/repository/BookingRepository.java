package com.bookmyhotel.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bookmyhotel.model.Booking;
import com.bookmyhotel.model.Hotel;
import com.bookmyhotel.model.User;
@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

 List<Booking> findByUserOrderByBookingDateDesc(User user);
 List<Booking> findByHotel(Hotel hotel);
@Query("SELECT b FROM Booking b WHERE b.hotel.id= :hotelId AND ((b.fromDate BETWEEN :fromDate AND :toDate ) OR ( b.toDate BETWEEN :fromDate AND :toDate))")
List<Booking> findByFromDateAndToDate(@Param("fromDate") Date fromDate,@Param("toDate") Date toDate,@Param("hotelId") Long hotelId);
}
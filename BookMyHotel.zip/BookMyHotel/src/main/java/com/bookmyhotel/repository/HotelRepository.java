package com.bookmyhotel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookmyhotel.model.City;
import com.bookmyhotel.model.Hotel;
@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {
    List<Hotel> findByCityOrderByPriceAsc(City city);
    List<Hotel>findTop5ByCityOrderByPriceAsc(City city);
}
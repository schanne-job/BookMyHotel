package com.bookmyhotel.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.bookmyhotel.model.City;
import com.bookmyhotel.model.Hotel;

public class HotelRepositoryCustomImpl implements HotelRepositoryCustom{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<Hotel> findByCityWithLessPrice(City city) {
		Query query=em.createQuery("Select * from hotel h order");
		return null;
	}
	

}

package com.bookmyhotel.util;

import java.util.regex.Pattern;

public interface Constants {


 public static final Pattern VALID_EMAIL_ADDRESS_REGEX = 
		    Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
		    		+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
public static final String ERROR="error";
public static final String MESSAGE="message";
public static final String CITIES="cities";
public static final String BOOKING="booking";





}
